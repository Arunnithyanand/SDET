package com.example.demo;

import java.util.Iterator;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmbededMonoDBprojectApplication implements CommandLineRunner  {

	@Autowired
	private StudentRepo repo;
	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmbededMonoDBprojectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	
		
		repo.insert(new Student("12","prince","hydrabad"));
		repo.insert(new Student("13","deepak","banglore"));
		repo.insert(new Student("14","akash","delhi"));
		repo.insert(new Student("15","akhil","kochi"));
		
		System.out.println("Data is inserted in DB Embeded Mongo db");
		
		List<Student> s=repo.findAll();
		
		Iterator<Student> itr=s.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next().toString());
		}
		
		
		
		
		
		
	}

}
