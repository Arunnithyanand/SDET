package com.example.demo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Student {
	
	@Id
	private String name;
	private String rollno;
	private String location;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRollno() {
		return rollno;
	}
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", rollno=" + rollno + ", location=" + location + "]";
	}
	public Student(String name, String rollno, String location) {
		super();
		this.name = name;
		this.rollno = rollno;
		this.location = location;
	}
	public Student() {
		super();
	}
	
	
	

}
